import React from 'react';
import { StyleSheet, Text, View, Button, Alert, Pressable } from 'react-native';

export default function App({navigation}) {
  // Definição da função Lista
  const Lista = () => {
    // Lógica para a função Lista
    Alert.alert('Entrar clicado!');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Bem-vindo ao Meu App</Text>
      <Text style={styles.bodyText}>Esta é a sua página principal.</Text>
      <Button
        title="Clique Aqui"
        onPress={() => Alert.alert('Botão clicado!')}
      />
      <Pressable style={styles.button} onPress={navigation.navigate('Listar')}>
        <Text style={styles.buttonText}>Entrar</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  bodyText: {
    fontSize: 16,
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#FA662A',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});
