// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAN5mDO15DpZZtpk0uJ0ln0qIzyqpNl4dE",
  authDomain: "aula-um-alice.firebaseapp.com",
  projectId: "aula-um-alice",
  storageBucket: "aula-um-alice.appspot.com",
  messagingSenderId: "1079515377026",
  appId: "1:1079515377026:web:4877ac1437a513d851b39b",
  measurementId: "G-S9TXM3MC7Z"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export default app;